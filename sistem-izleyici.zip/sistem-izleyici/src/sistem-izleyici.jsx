import React, { useState, useEffect, useRef } from "react";
import { LineChart, Line, ResponsiveContainer, YAxis } from "recharts";
import { ChevronDown, Cpu, MonitorSmartphone, MemoryStick, Thermometer, Activity } from "lucide-react";

// ---- yardımcı: rastgele yürüyüş ile gerçekçi dalgalanma ----
function useLiveValue(base, variance, min = 0, max = 100) {
  const [val, setVal] = useState(base);
  const ref = useRef(base);
  useEffect(() => {
    const id = setInterval(() => {
      let next = ref.current + (Math.random() - 0.5) * variance;
      next = Math.max(min, Math.min(max, next));
      ref.current = next;
      setVal(next);
    }, 1400);
    return () => clearInterval(id);
  }, [variance, min, max]);
  return val;
}

function useHistory(value, length = 24) {
  const [hist, setHist] = useState(Array(length).fill(value));
  useEffect(() => {
    setHist((h) => [...h.slice(1), value]);
  }, [value]);
  return hist;
}

const cpuProcs = [
  { name: "chrome.exe", detail: "Web tarayıcı · 34 sekme" },
  { name: "Discord.exe", detail: "Ses görüşmesi aktif" },
  { name: "svchost.exe", detail: "Sistem hizmetleri" },
  { name: "node.exe", detail: "Geliştirme sunucusu" },
  { name: "Explorer.exe", detail: "Dosya gezgini" },
];
const gpuProcs = [
  { name: "Cyberpunk2077.exe", detail: "4K · DLSS Kalite" },
  { name: "chrome.exe", detail: "Donanım ivmesi" },
  { name: "OBS Studio", detail: "1080p60 kayıt" },
  { name: "dwm.exe", detail: "Masaüstü penceresi yöneticisi" },
];
const ramProcs = [
  { name: "chrome.exe", detail: "3.2 GB" },
  { name: "Cyberpunk2077.exe", detail: "6.8 GB" },
  { name: "Discord.exe", detail: "540 MB" },
  { name: "Sistem önbelleği", detail: "2.1 GB" },
];

const sensors = [
  { label: "İşlemci", key: "cpu", base: 58 },
  { label: "Ekran Kartı", key: "gpu", base: 64 },
  { label: "Anakart (VRM)", key: "vrm", base: 44 },
  { label: "Depolama (NVMe)", key: "ssd", base: 39 },
];

function Ring({ pct, color, glow, size = 128, stroke = 10 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="#1B2233" strokeWidth={stroke} fill="none" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        stroke={color}
        strokeWidth={stroke}
        fill="none"
        strokeDasharray={c}
        strokeDashoffset={offset}
        strokeLinecap="round"
        style={{ filter: `drop-shadow(0 0 8px ${glow})`, transition: "stroke-dashoffset 1s ease" }}
      />
    </svg>
  );
}

function MetricCard({ icon: Icon, title, subtitle, value, color, glow, procs, unit = "%" }) {
  const [open, setOpen] = useState(false);
  const hist = useHistory(value);

  return (
    <div
      className="rounded-3xl p-5 border border-white/5 backdrop-blur-sm transition-all duration-300"
      style={{ background: "linear-gradient(155deg, #131826 0%, #0F131F 100%)" }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center"
            style={{ background: `${color}22`, color }}
          >
            <Icon size={20} strokeWidth={2.2} />
          </div>
          <div>
            <p className="text-[15px] font-semibold text-slate-100 tracking-tight">{title}</p>
            <p className="text-[12px] text-slate-500">{subtitle}</p>
          </div>
        </div>
        <button
          onClick={() => setOpen(!open)}
          className="text-slate-500 hover:text-slate-300 transition-colors p-1"
        >
          <ChevronDown size={18} className={`transition-transform duration-300 ${open ? "rotate-180" : ""}`} />
        </button>
      </div>

      <div className="flex items-center gap-5 mt-4">
        <div className="relative flex items-center justify-center" style={{ width: 128, height: 128 }}>
          <Ring pct={value} color={color} glow={glow} />
          <div className="absolute flex flex-col items-center">
            <span className="text-2xl font-bold text-slate-50 tabular-nums">{Math.round(value)}{unit}</span>
          </div>
        </div>
        <div className="flex-1 h-16">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={hist.map((v, i) => ({ i, v }))}>
              <YAxis domain={[0, 100]} hide />
              <Line
                type="monotone"
                dataKey="v"
                stroke={color}
                strokeWidth={2}
                dot={false}
                isAnimationActive={false}
              />
            </LineChart>
          </ResponsiveContainer>
          <p className="text-[11px] text-slate-500 mt-1">son 45 saniye</p>
        </div>
      </div>

      <div
        className="overflow-hidden transition-all duration-300"
        style={{ maxHeight: open ? 240 : 0, opacity: open ? 1 : 0 }}
      >
        <div className="pt-4 mt-3 border-t border-white/5 space-y-2.5">
          <p className="text-[11px] uppercase tracking-wider text-slate-500 font-medium">En çok kullanan</p>
          {procs.map((p, idx) => (
            <div key={idx} className="flex items-center justify-between text-[13px]">
              <span className="text-slate-300">{p.name}</span>
              <span className="text-slate-500">{p.detail}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TempStrip() {
  const vals = sensors.map((s) => useLiveValue(s.base, 6, 28, 92));
  return (
    <div
      className="rounded-3xl p-5 border border-white/5"
      style={{ background: "linear-gradient(155deg, #131826 0%, #0F131F 100%)" }}
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-2xl flex items-center justify-center bg-orange-400/10 text-orange-300">
          <Thermometer size={20} strokeWidth={2.2} />
        </div>
        <div>
          <p className="text-[15px] font-semibold text-slate-100 tracking-tight">Sıcaklıklar</p>
          <p className="text-[12px] text-slate-500">Anlık sensör verileri</p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {sensors.map((s, i) => {
          const v = vals[i];
          const hot = v > 75;
          const warm = v > 60;
          const color = hot ? "#F45B69" : warm ? "#F0A868" : "#5FD9B8";
          return (
            <div key={s.key} className="rounded-2xl px-4 py-3 bg-white/[0.03] border border-white/5">
              <div className="flex items-center justify-between">
                <span className="text-[12px] text-slate-400">{s.label}</span>
                <span className="text-[15px] font-bold tabular-nums" style={{ color }}>
                  {Math.round(v)}°C
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-white/5 mt-2 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${Math.min(100, (v / 100) * 100)}%`, background: color }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function SystemMonitor() {
  const cpu = useLiveValue(52, 14);
  const gpu = useLiveValue(61, 16);
  const ramPct = useLiveValue(47, 6, 10, 95);
  const ramUsedGB = (ramPct / 100) * 32;
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div
      className="min-h-screen w-full p-8"
      style={{
        background: "radial-gradient(ellipse at top left, #151B2E 0%, #0A0D16 55%, #06070C 100%)",
        fontFamily: "'Plus Jakarta Sans', 'Inter', system-ui, sans-serif",
      }}
    >
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap"
        rel="stylesheet"
      />

      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-400/20 to-violet-500/20 flex items-center justify-center text-indigo-300">
              <Activity size={22} strokeWidth={2.4} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-50 tracking-tight">Sistem İzleyici</h1>
              <p className="text-[13px] text-slate-500">Gerçek zamanlı donanım kullanımı</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[13px] font-medium text-slate-300 tabular-nums">
              {time.toLocaleTimeString("tr-TR")}
            </p>
            <p className="text-[11px] text-slate-500">{time.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long" })}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <MetricCard
            icon={Cpu}
            title="İşlemci"
            subtitle="Ryzen 7 · 8 çekirdek"
            value={cpu}
            color="#6C8EF5"
            glow="#6C8EF588"
            procs={cpuProcs}
          />
          <MetricCard
            icon={MonitorSmartphone}
            title="Ekran Kartı"
            subtitle="RTX seri · 12 GB VRAM"
            value={gpu}
            color="#B389F9"
            glow="#B389F988"
            procs={gpuProcs}
          />
          <MetricCard
            icon={MemoryStick}
            title="Bellek (RAM)"
            subtitle={`${ramUsedGB.toFixed(1)} GB / 32 GB kullanılıyor`}
            value={ramPct}
            color="#5FD9B8"
            glow="#5FD9B888"
            procs={ramProcs}
          />
        </div>

        <TempStrip />

        <p className="text-center text-[11px] text-slate-600 mt-6">
          Bu bir tasarım gösterimidir · veriler örnek amaçlı simüle edilmiştir
        </p>
      </div>
    </div>
  );
}
